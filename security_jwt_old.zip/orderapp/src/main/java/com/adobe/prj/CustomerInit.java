package com.adobe.prj;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.adobe.prj.dao.CustomerDao;
import com.adobe.prj.entity.Customer;

@Order(1)
@Component
public class CustomerInit implements CommandLineRunner {
	@Autowired
	private CustomerDao customerDao;
	
	@Override
	public void run(String... args) throws Exception {
		if(customerDao.count() == 0) {
			Customer c1 = Customer.builder()
					.email("a@adobe.com")
					.firstName("Asha").lastName("Patel").build();
			
			Customer c2 = Customer.builder()
						.email("b@adobe.com")
						.firstName("Bharath")
						.lastName("Sharma")
						.build();
			
			customerDao.save(c1);
			customerDao.save(c2);
		}
	}

}
