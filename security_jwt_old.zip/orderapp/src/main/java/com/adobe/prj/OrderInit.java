package com.adobe.prj;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.adobe.prj.entity.Customer;
import com.adobe.prj.entity.Item;
import com.adobe.prj.entity.Product;
import com.adobe.prj.service.OrderService;

@Order(2)
@Component
public class OrderInit implements CommandLineRunner {
	@Autowired
	private OrderService service;
	
	@Override
	public void run(String... args) throws Exception {
//		insertOrders();
//		listOrders();
	}

	private void listOrders() {
		List<com.adobe.prj.entity.Order> orders = service.getOrders();
		for(com.adobe.prj.entity.Order o : orders) {
			System.out.println(o.getCustomer().getEmail());
			for(Item i : o.getItems()) {
				System.out.println(i.getProduct().getName() + ", " + i.getQuantity());
			}
			System.out.println(o.getTotal());
			System.out.println("**********");
		}
	}

	private void insertOrders() {
		com.adobe.prj.entity.Order order = new com.adobe.prj.entity.Order();
		order.setCustomer(Customer.builder().email("a@adobe.com").build());
		List<Item> items = new ArrayList<Item>();	
		
		Item i1 = Item.builder()
				.product(Product.builder().id(1).build())
				.quantity(3).build();
		
		Item i2 = Item.builder()
				.product(Product.builder().id(2).build())
				.quantity(5).build();
		items.add(i1);
		items.add(i2);
		
		order.setItems(items);
		
		service.placeOrder(order);
	}
	
	

}
