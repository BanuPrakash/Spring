package com.adobe.prj.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.adobe.prj.dao.OrderDao;
import com.adobe.prj.dao.ProductDao;
import com.adobe.prj.entity.Item;
import com.adobe.prj.entity.Order;
import com.adobe.prj.entity.Product;

@Service
public class OrderService {
	@Autowired
	private ProductDao productDao;
	
	@Autowired
	private OrderDao orderDao;
	
	/* 
		{
		  "customer": "a@adobe.com",
		   "items" : [
		       {"product": {"id": 2}, "quantity" : 2},
		       {"product": {"id": 1}, "quantity" : 1}
		   ]
		} 
	*/
	@Transactional
	public Order placeOrder(Order o) {
		List<Item> items = o.getItems();
		double total = 0.0; 
		for(Item i : items) {
			Product p = productDao.findById(i.getProduct().getId()).get();
			p.setQuantity(p.getQuantity() - i.getQuantity()); //Dirty Checking ==> update
			i.setAmount(p.getPrice() * i.getQuantity());
			total += i.getQuantity() * p.getPrice();
		}
		o.setTotal(total);
		return orderDao.save(o); //cascade saves items
	}
	
	public List<Order> getOrders() {
		return orderDao.findAll();
	}
	
	public Product insertProduct(Product p) {
		return productDao.save(p);
	}
	
	public List<Product> getProducts() {
		return productDao.findAll();
	}
	
	public List<Product> getByRange(double lo, double hi) {
		return productDao.queryByRange(lo, hi);
	}
	
	@Transactional
	public Product updateProduct(int id, double price) throws NotFoundException {
		productDao.updateProduct(id, price);
		return getProductById(id);
	}
	
	public Product getProductById(int id) throws NotFoundException {
		Optional<Product> opt = productDao.findById(id);
		if(opt.isPresent()) {
			return opt.get();
		} else {
			throw new NotFoundException("Product with id " + id + " not exists!!!");
		}
	}
}

