package com.adobe.prj.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Version;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "products")
public class Product implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) // AUTO_INCREMENT
	private int id;

	@NotBlank(message = "Name is required")
	private String name;

	@Min(value = 10, message = "Price ${validatedValue} should be more than {value}")
	private double price;

	@Min(value = 0, message = "Quantity ${validatedValue} should be more than {value}")
	@Column(name = "qty")
	private int quantity;

	@Version
	@Column(name = "ver")
	private int version;

}
