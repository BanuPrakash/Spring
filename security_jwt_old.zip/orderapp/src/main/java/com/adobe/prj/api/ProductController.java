package com.adobe.prj.api;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.afford;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.adobe.prj.entity.Product;
import com.adobe.prj.service.NotFoundException;
import com.adobe.prj.service.OrderService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@Validated
@RestController
@RequestMapping("api/products")
@Tag(name="Products", description = "Product APIs")
public class ProductController {
	@Autowired
	private OrderService service;
	
	
	@PreAuthorize("hasRole('ADMIN')")
	@GetMapping("/hateoas/{id}")
	public @ResponseBody ResponseEntity<EntityModel<Product>> getProductHateos(@PathVariable("id") int id) throws NotFoundException {
		 Product p = service.getProductById(id);
		 EntityModel<Product> entityModel = EntityModel.of(p,
				 linkTo(methodOn(ProductController.class).getProductHateos(id)).withSelfRel()
				 .andAffordance(afford(methodOn(ProductController.class).updateProduct(id, null))),
				 linkTo(methodOn(ProductController.class).getProducts(0,0)).withRel("products"));
		 return ResponseEntity.ok(entityModel);
	}
	
	// http://localhost:8080/api/products
	// http://localhost:8080/api/products?low=500&high=2000
	
	@Secured({"ROLE_ADMIN", "ROLE_USER"})
	@GetMapping()
	public @ResponseBody List<Product> getProducts(
			@RequestParam(name="low", defaultValue = "0.0") double low,
			@RequestParam(name="high", defaultValue = "0.0") double high) {
		if(low == 0.0 && high == 0.0) {
			return service.getProducts();
		} 
		return service.getByRange(low, high);
	}
	
	// ETAG
		@GetMapping("/cache/{id}")
		public  ResponseEntity<Product> getProductCache(@PathVariable("id") int id) throws NotFoundException {
			Product p = service.getProductById(id);
			return ResponseEntity.ok().eTag(Long.toString(p.hashCode())).body(p);
		}
	
	// http://localhost:8080/api/products/4
	@GetMapping("/{id}")
	@Cacheable(value="productCache", key="#id")
	@Operation(summary = "Get Product by its id")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Found product for given ID")
	})
	public @ResponseBody Product getProduct(@PathVariable("id") int id) throws NotFoundException {
		System.out.println("Cache Miss!!!");
		try {
			Thread.sleep(2000);
		} catch(Exception ex) {}
		return service.getProductById(id);
	}
	
	@PostMapping()
	@Cacheable(value="productCache", key="#p.id", condition = "#p.price > 5000")
	public ResponseEntity<Product> addProduct(@RequestBody @Valid Product p) {
		service.insertProduct(p);
		return new ResponseEntity<Product>(p, HttpStatus.CREATED);
	}
	
	@GetMapping("/clear-cache")
	@CacheEvict(value="productCache", allEntries = true)
	public @ResponseBody String clear(){
		return "Cache cleared!!!";
	}
	
	@PutMapping("/{id}")
	@CachePut(value="productCache", key="#id")
	public ResponseEntity<Product> updateProduct(@PathVariable("id") int id, @RequestBody Product p) {
		return new ResponseEntity<Product>(p, HttpStatus.CREATED);
	}
	
	@DeleteMapping("/{id}")
	public void deleteProduct(@PathVariable("id") int id) {
	}
}
