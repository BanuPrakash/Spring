package com.adobe.prj;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;

import com.adobe.prj.entity.Product;
import com.adobe.prj.service.NotFoundException;
import com.adobe.prj.service.OrderService;

@Configuration
public class ProductInitConfig  implements CommandLineRunner {
	@Autowired
	private OrderService service;
	
	@Override
	public void run(String... args) throws Exception {
/*		addProducts();
		System.out.println("All");
		listProducts();
		System.out.println("Range");
		getRangeWise();
		
		System.out.println("updating price");
		modifyPrice();
	*/
	}

	private void modifyPrice() throws NotFoundException {
		Product p = service.updateProduct(1, 138999.00);
		System.out.println(p);
		
	}

	private void getRangeWise() {
		List<Product> products = service.getByRange(500, 5000);
		for(Product p : products) {
			System.out.println(p); // toString()
		}
	}

	private void listProducts() {
		List<Product> products = service.getProducts();
		for(Product p : products) {
			System.out.println(p); // toString()
		}
	}

	private void addProducts() {
		Product p1 = 
				Product.builder()
				.name("Mouse")
				.price(900.00)
				.quantity(100)
				.build();
		 
		
		Product p2 = new Product();
		p2.setName("Wacom");
		p2.setPrice(1400.00);
		p2.setQuantity(100);
		
		service.insertProduct(p1);
		service.insertProduct(p2);
	}
}
