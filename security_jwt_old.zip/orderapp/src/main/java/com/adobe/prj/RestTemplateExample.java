package com.adobe.prj;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.adobe.prj.entity.Product;

@Configuration
public class RestTemplateExample implements CommandLineRunner {
	@Autowired
	RestTemplate template;
	
	@Override
	public void run(String... args) throws Exception {
//		getProducts();
//		getProduct();
		
//		addProduct();
	}

	private void addProduct() {
		Product p = Product.builder().name("Some Item").price(10.00).quantity(4100).build();
		
		ResponseEntity<Product> responseEntity = 
				template.postForEntity("http://localhost:8080/api/products", p, Product.class);
		
		System.out.println(responseEntity.getStatusCodeValue()); // 201
	}

	private void getProduct() {
		ResponseEntity<Product> responseEntity =
				template.getForEntity("http://localhost:8080/api/products/2", Product.class);
		System.out.println(responseEntity.getBody());
	}

	private void getProducts() {
		String str = template.getForObject("http://localhost:8080/api/products", String.class);
		System.out.println(str);
	}
	
	
	
	
	
}
