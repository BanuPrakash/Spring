package com.adobe.prj.service;

public class NotFoundException extends Exception {

	public NotFoundException(String string) {
		super(string);
	}

	private static final long serialVersionUID = 1L;

}
